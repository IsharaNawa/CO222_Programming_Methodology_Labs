/*
   vigenere.h

   Sample program for CO222 Lab11-Part1
*/

#define MAX_KEY 128

extern char key[MAX_KEY];

void encrypt( int ch );
